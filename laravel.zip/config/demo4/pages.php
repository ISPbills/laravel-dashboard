<?php
return array(
    '' => array(
        'title'  => 'Dashboard',
        'view'   => 'index',
        'layout' => array(
            'page-title' => array(
                'description' => false,
                'breadcrumb'  => true,
            ),
        ),
    ),
);
