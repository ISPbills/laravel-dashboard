<?php
return array(
    'main' => array(
        array(
            'title' => 'Ask Question',
            'path'  => 'apps/devs/ask',
        ),
        array(
            'title' => 'Search',
            'path'  => 'apps/devs/search',
        ),
        array(
            'title' => 'Tags',
            'path'  => 'apps/devs/tag',
        ),
        array(
            'title' => 'Question',
            'path'  => 'apps/devs/question',
        ),
    ),
);
