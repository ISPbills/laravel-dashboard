<?php
return array(

    'login'           => array(
        'title'  => 'Login',
        'layout' => array(
            'main' => array(
                'body' => array(
                    'background-image' => null,
                ),
            ),
        ),
    ),
    'register'        => array(
        'title'  => 'Register',
        'layout' => array(
            'main' => array(
                'body' => array(
                    'background-image' => null,
                ),
            ),
        ),
    ),
    'forgot-password' => array(
        'title'  => 'Forgot Password',
        'layout' => array(
            'main' => array(
                'body' => array(
                    'background-image' => null,
                ),
            ),
        ),
    ),

);
