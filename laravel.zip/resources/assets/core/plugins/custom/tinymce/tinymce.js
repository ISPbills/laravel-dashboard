// TinyMCE: The rich text editor built to scale, designed to innovate, and developed in open source: https://www.tiny.cloud/

require('tinymce/tinymce.js');
require('tinymce/icons/default/icons.js');
require('tinymce/themes/silver/theme.js');
require('tinymce/themes/mobile/theme.js');
